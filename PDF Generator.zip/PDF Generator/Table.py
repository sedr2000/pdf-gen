from tkinter import *
from tkinter import ttk
def Insert_into_table(row_data,table):
    table.insert('', 'end', text="",
                         values=row_data)
def fetch_table_data(table):
    data = []
    for line in table.get_children():
       rows = []
       for value in table.item(line)['values']:
           rows.append(value)
       data.append(rows)
    print(data)
    return data
def Generate_Table(myFrame,width,title,x,y):
    tableFrame = Frame(myFrame, width=770, height=300)
    tableFrame.pack()
    tableFrame.place(x=x, y=y)
    mylist = []
    for i in range(1,len(title)+1):
        mylist.append(i)
    scrollbar = ttk.Scrollbar(tableFrame, orient=VERTICAL)
    scrollbar.pack(side=RIGHT, fill=Y)

    treeStyle = ttk.Style()
    treeStyle.theme_use("alt")
    print(treeStyle.theme_names())
    treeStyle.configure("Treeview", background="silver", foreground="blue", fieldbackground="white", rowheight=35,
                        relief="raised", font=("Times 16 bold"),height=20)

    # TreeStyle.map("Treeview", background=[('selected', 'red')])

    # Creating Table
    table = ttk.Treeview(tableFrame, columns=(mylist), show="headings", style="Treeview",
                              yscrollcommand=scrollbar)
    index = 1
    for i in range(len(title)):
        table.heading(index, text=title[i])
        table.column(index, width=width[i])
        index += 1
    # tags
    table.tag_configure("Treeview", background="black", foreground="white", font=("Times 12"))

    table.pack()
    # Salerydata.bind("<ButtonRelease-1>", PaySalery)
    # Salerydata.bind("<Up>", PaySalery)
    # Salerydata.bind("<Down>", PaySalery)
    scrollbar.config(command=table.yview)
    return table