from reportlab.lib.units import inch, cm
from reportlab.lib.pagesizes import LETTER,LEGAL,landscape
from reportlab.platypus import Table, SimpleDocTemplate,TableStyle
from tkinter import *
from Table import Generate_Table,Insert_into_table,fetch_table_data
def Generate_Pdf():
    heading = ["Sr#","Item Name","Qty","Price","Amount"]
    Data = fetch_table_data(table=table)
    final_list = [heading]
    for i in Data:
        final_list.append(i)
    table_data = Table(final_list)
    pdf = SimpleDocTemplate("Result Card",pagesize=LEGAL)
    TitleData = [[]]*2
    TitleData[0] = ["CANTEEN"]
    TitleData[1]=  ["PAYMENT RECEIPT"]
    TitleTable = Table(TitleData)
    TitleStyle =TableStyle([
        ('ALIGN',(0,0),(-1,-1),'CENTER'),
        ('FONTNAME', (0, 0), (-1, 0), 'Courier-Bold'),
        ("FONTSIZE", (0, 0), (-1, -1), 16),
        ("FONTSIZE", (0, 1), (-1, 1), 11),
        ('TOPPADDING', (0, 0), (-1, -1), 10),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 10),
        ('BOX',(0,1),(-1,1),0.5,'black')
    ])
    TitleTable.setStyle(TitleStyle)
    style = TableStyle([
        ('ALIGN',(0,0),(-1,-1),'CENTER'),
        ('FONTNAME',(0,0),(-1,0),'Courier-Bold'),
        ("FONTSIZE",(0,0),(-1,0),14),
        ('BOTTOMPADDING',(0,0),(-1,0),12),
        ('BOX',(0,0),(-1,-1),2,'black'),
        ('GRID',(0,0),(-1,-1),2,'black')
    ])
    table_data.setStyle(style)
    elems = [TitleTable,table_data]
    pdf.build(elems)

global count 
count = 0
def Set_Data():
    global count
    count += 1
    final_list = [count]
    for i in range(3,6):
        final_list.append(entries[i].get())
    final_list.append(int(entries[4].get())*int(entries[5].get()))
    return final_list
def Insert_Data():
    final_list = Set_Data()
    Insert_into_table(row_data=final_list,table=table)

window = Tk()
window.geometry("700x700")
window.title("Reciept Generator")
frame = Frame(window,bg="white")
frame.pack(fill=BOTH,expand=1)
title = Label(frame,text="Generate Reciept",bg="white",fg="black",font=("Times 25 bold"))
title.pack()
title.place(x=200,y=20)
next_frame = LabelFrame(frame,width=650,height=150,bg="white")
next_frame.pack()
next_frame.place(x=25,y=220)
title_list = ["Customer Name","Address","Contact","Item Name","Quantity","Price"]
y = 100
entries = []
for i in range(len(title_list)):
    if i < 3:
        use_frame = frame
    else:
        if i == 3:
            y = 10
        use_frame = next_frame
    label = Label(use_frame,text=title_list[i],bg="white",fg="black",font=("Times 14"))
    label.pack()
    label.place(x=20,y=y)
    entry = Entry(use_frame,width=30,font=("Times 14"),bg="white",fg="black")
    entry.pack()
    entry.place(x=200,y=y)
    y += 40
    entries.append(entry)
table = Generate_Table(myFrame=frame,width=[50,300,90,90,90],title=["Sr#","Item Name","Qty","Price","Amount"],x=20,y=390)
buttons = ["Add","Generate Pdf"]
button_commands = [Insert_Data,Generate_Pdf]
y = 50
for i in range(len(buttons)):
    but = Button(next_frame,text=buttons[i],width=10,font=("Times 14"),command=button_commands[i])
    but.pack()
    but.place(x=500,y=y)
    y += 40
entries[0].focus()
window.mainloop()